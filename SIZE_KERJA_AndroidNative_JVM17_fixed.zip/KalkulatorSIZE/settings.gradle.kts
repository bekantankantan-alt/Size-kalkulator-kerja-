pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); google(); mavenCentral() }
rootProject.name = "KalkulatorSIZE"
include(":app")
