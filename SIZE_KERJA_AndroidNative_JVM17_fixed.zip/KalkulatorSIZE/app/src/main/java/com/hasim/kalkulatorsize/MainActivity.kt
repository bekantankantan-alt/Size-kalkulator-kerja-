package com.hasim.kalkulatorsize

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.round

private val Coal = Color(0xFF080A0D)
private val Panel = Color(0xFF171B20)
private val Gold = Color(0xFFFFD21A)
private val Orange = Color(0xFFFF8B00)
private val Muted = Color(0xFF9AA5B1)
private val Green = Color(0xFF6CE0A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,10,13)
        window.navigationBarColor = android.graphics.Color.rgb(8,10,13)
        setContent { SizeWorkApp() }
    }
}

private data class SizeRow(val title: String, val text: String)

private fun parseIdNumber(raw: String): Double? =
    raw.trim().replace(" ", "").replace(".", "").replace(",", ".").toDoubleOrNull()

private fun ton(n: Double): String {
    val symbols = DecimalFormatSymbols(Locale("id", "ID")).apply { groupingSeparator = '.' }
    return DecimalFormat("#,##0", symbols).format(n)
}
private fun percent(n: Double): String {
    val symbols = DecimalFormatSymbols(Locale("id", "ID")).apply { decimalSeparator = ',' }
    return DecimalFormat("0.00", symbols).format(n) + "%"
}

@Composable
private fun SizeWorkApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("size_work", Context.MODE_PRIVATE) }
    var bg by remember { mutableStateOf("L1") }
    var initial by remember { mutableStateOf("52160") }
    var plusInput by remember { mutableStateOf("3630") }
    var percentMode by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<SizeRow?>(null) }
    var history by remember {
        mutableStateOf(runCatching {
            val arr = JSONArray(prefs.getString("history", "[]"))
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrDefault(emptyList()))
    }

    fun saveHistory(newText: String) {
        val updated = (listOf(newText) + history).take(12)
        history = updated
        val arr = JSONArray()
        updated.forEach { arr.put(it) }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Coal, surface = Panel,
        onPrimary = Color(0xFF151515), onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF33240B), Coal, Coal))
            ).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // The custom launcher artwork is also shown in the app header.
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(id = com.hasim.kalkulatorsize.R.mipmap.ic_launcher),
                    contentDescription = "SIZE KERJA icon",
                    modifier = Modifier.size(70.dp)
                )
                Column {
                    Text("SIZE KERJA", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("KALKULATOR MUATAN • JETTY", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Muted, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF201B12),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF4A3A17), RoundedCornerShape(20.dp))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("TOOL • SIZE CALC", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Black)
                    Text("Hitung muatan lebih cepat.", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("Masukkan data BG atau line, pilih mode +50, lalu hitung.", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(13.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("01", "DATA MUATAN")
                    FieldLabel("NAMA BG / LINE")
                    OutlinedTextField(
                        value = bg, onValueChange = { bg = it; error = "" },
                        placeholder = { Text("Contoh: BG APAR / L1", color = Color(0xFF606B78)) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                    )
                    FieldLabel("MUATAN AWAL • TON")
                    OutlinedTextField(
                        value = initial, onValueChange = { initial = it; error = "" },
                        placeholder = { Text("Mis. 52160", color = Color(0xFF606B78)) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModeButton("+50 DALAM TON", !percentMode, Modifier.weight(1f)) { percentMode = false }
                        ModeButton("+50 DALAM %", percentMode, Modifier.weight(1f)) { percentMode = true }
                    }
                    FieldLabel(if (percentMode) "NILAI +50 • PERSEN" else "NILAI +50 • TON")
                    OutlinedTextField(
                        value = plusInput, onValueChange = { plusInput = it; error = "" },
                        placeholder = { Text(if (percentMode) "Mis. 5,32" else "Mis. 3630", color = Color(0xFF606B78)) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                    )
                    Button(
                        onClick = {
                            val a = parseIdNumber(initial); val p = parseIdNumber(plusInput)
                            error = ""; output = null
                            when {
                                bg.isBlank() -> error = "Isi nama BG atau line."
                                a == null || a <= 0 -> error = "Muatan awal harus lebih dari nol."
                                p == null || p < 0 -> error = "Nilai +50 tidak valid."
                                else -> {
                                    val roundedInitial = round(a)
                                    val plus = if (percentMode) round((a * p / 100.0) / 10.0) * 10.0 else p
                                    if (plus > roundedInitial) error = "Nilai +50 tidak boleh melebihi muatan awal."
                                    else {
                                        val minus = roundedInitial - plus
                                        val text = "✦ ${bg.trim()} ✦\n\nMuatan Awal : ${ton(roundedInitial)} (100,00%)\n+50 : ${ton(plus)} (${percent(plus / roundedInitial * 100)})\n−50 : ${ton(minus)} (${percent(minus / roundedInitial * 100)})"
                                        output = SizeRow(bg.trim(), text)
                                        saveHistory(text)
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(52.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF151515))
                    ) { Text("HITUNG SIZE  ↗", fontWeight = FontWeight.Black, letterSpacing = .5.sp) }
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Text("Nama BG/line memakai keyboard QWERTY. Kolom tonase memakai keyboard angka.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
            output?.let { result ->
                Spacer(Modifier.height(13.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF211C12)), shape = RoundedCornerShape(18.dp), modifier = Modifier.border(1.dp, Color(0xFF63501D), RoundedCornerShape(18.dp))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("HASIL PERHITUNGAN", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Black)
                        Text("✦ ${result.title} ✦", fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
                        val lines = result.text.split("\n").filter { it.isNotBlank() && !it.startsWith("✦") }
                        lines.forEachIndexed { i, line ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(line.substringBefore(" : "), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(line.substringAfter(" : "), color = when(i) { 1 -> Green; 2 -> Color(0xFFFFD15B); else -> Color.White }, fontSize = 14.sp, fontWeight = FontWeight.Black)
                            }
                            if (i < lines.lastIndex) HorizontalDivider(color = Color(0xFF30343A))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                            Button(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("SIZE", result.text))
                            }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("▣ SALIN", fontWeight = FontWeight.Black) }
                            OutlinedButton(onClick = {
                                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, result.text)
                                }, "Bagikan hasil SIZE"))
                            }, modifier = Modifier.weight(1f)) { Text("↗ BAGIKAN", fontWeight = FontWeight.Black) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(13.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("02", "RIWAYAT TERSIMPAN")
                    if (history.isEmpty()) Text("Hasil hitungan tersimpan lokal di perangkat.", color = Muted, fontSize = 12.sp)
                    else {
                        history.forEachIndexed { index, item ->
                            Text(item, color = Color(0xFFCBD2DA), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                            if (index < history.lastIndex) HorizontalDivider(color = Color(0xFF303741))
                        }
                        TextButton(onClick = { history = emptyList(); prefs.edit().remove("history").apply() }) { Text("HAPUS RIWAYAT", color = Gold, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("SIZE KERJA • OFFLINE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable private fun SectionTitle(n: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.size(25.dp).background(Gold, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Text(n, color = Color(0xFF171717), fontSize = 12.sp, fontWeight = FontWeight.Black)
        }
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
    }
}
@Composable private fun FieldLabel(s: String) {
    Text(s, color = Color(0xFFADB8C3), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
}
@Composable private fun ModeButton(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(42.dp), shape = RoundedCornerShape(11.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (active) Gold else Color(0xFF222831), contentColor = if (active) Color(0xFF151515) else Color(0xFFCBD2DB)),
        contentPadding = PaddingValues(horizontal = 6.dp)) { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Black) }
}
@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF343D48),
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedContainerColor = Color(0xFF090C10), unfocusedContainerColor = Color(0xFF090C10),
    cursorColor = Gold, focusedLabelColor = Gold, unfocusedLabelColor = Muted
)
